<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Erro</title>
	<link rel="stylesheet" href="">
</head>
<body>
<?php
//var_dump($_GET);
//var_dump($_SERVER);
?>
	<h2>ERRO, PÁGINA NÃO ENCONTRADA</h2>
</body>
</html>