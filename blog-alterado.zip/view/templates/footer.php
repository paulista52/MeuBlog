				</div>
				<!-- Footer content -->
				<footer class="page-footer white">
					<div class="footer-copyright center">
						<div class="container black-text text-lighten-4">
							<?php echo date('Y'); ?> Blog Km |
							<a target="_blank" href="https://github.com/viniciusbeckerbernardini/freeBlog">GitHub</a>
						</div>
					</div>
					<!-- End of footer content -->
				</footer>
			</section>
			<!-- Loading system scripts -->
			<script src="<?php siteUrl(); ?>/view/library/js/jquery.js"></script>
			<script src="https://cdn.ckeditor.com/ckeditor5/11.2.0/classic/ckeditor.js"></script>
			<script src="<?php siteUrl(); ?>/view/library/js/jQuery.mask.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
			<script src="<?php siteUrl(); ?>/view/library/js/07b0ce5d10.js"></script>
			<script src="<?php siteUrl(); ?>/view/library/js/my-js.js"></script>
			<!-- End of loading system scripts -->
		</body>
		</html>		