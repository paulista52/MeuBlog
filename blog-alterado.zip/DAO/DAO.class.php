<?php 
// Silence is golden
// In the future
 ?>