<?php 

class Validation{
	
}