<?php 
/**
This is te freeBlog configuration file
DON'T EDIT IF YOU DONT KNOW!
**/
// Requesting the functions file
require_once('functions.php');
// Development show errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);
// Making session start for every single file
session_start();



?>
